# raft-zh_cn
Raft一致性算法论文的中文翻译

英文[论文地址](https://ramcloud.atlassian.net/wiki/download/attachments/6586375/raft.pdf)

中文[翻译地址](https://github.com/maemual/raft-zh_cn/blob/master/raft-zh_cn.md)
